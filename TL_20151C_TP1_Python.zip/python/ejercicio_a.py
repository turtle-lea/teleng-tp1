# -*- coding: utf-8 -*- 
#!/usr/bin/python


def afd_minimo(archivo_regex, archivo_automata):
    raise NotImplementedError
