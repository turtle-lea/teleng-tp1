# -*- coding: utf-8 -*- 
#!/usr/bin/python


def complemento(archivo_automata1, archivo_automata):
    raise NotImplementedError
