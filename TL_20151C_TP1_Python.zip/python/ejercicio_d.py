# -*- coding: utf-8 -*- 
#!/usr/bin/python


def interseccion(archivo_automata1, archivo_automata2, archivo_automata):
    raise NotImplementedError
