# -*- coding: utf-8 -*- 
#!/usr/bin/python


def pertenece_al_lenguaje(archivo_automata, cadena):
    raise NotImplementedError
