Hay un archivo por ejercicio y un archivo principal llamado "AFD.py".
La idea es que implementen la funcion que hay en cada archivo.
No necesitan modificar el archivo "AFD.py".

Cada parametro llamado "archivo..." es un archivo ya abierto,
listo para ser leido o escrito.

Para ejecutar:

python AFD.py <parametros>

Si lo ejecutan sin parametros muestra una ayuda.