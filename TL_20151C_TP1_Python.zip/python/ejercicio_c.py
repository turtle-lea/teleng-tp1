# -*- coding: utf-8 -*- 
#!/usr/bin/python


def grafo(archivo_automata, archivo_dot):
    raise NotImplementedError
